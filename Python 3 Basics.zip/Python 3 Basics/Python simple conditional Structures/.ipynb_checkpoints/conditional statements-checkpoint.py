#Exercise 42-Working with if statement
# 42.1 A sample file for working with conditional statements
def main():
    x,y=3,8 #define two variables
    if(x<y): #see out condition is met, by checking for condition of if statement
        st="x is less than y" #This variable is set and then printed
    print(st)
    
if __name__=="__main__":
    main()

# 42.2 A sample file for working with conditional statements
def main():
    x,y=9,8 #define two variables, this time x is greater
    if(x<y): #see out condition is not met, by checking for condition of if statement
        st="x is less than y" #This variable is not set 
    print(st)#Hence prints an error message,trying to print the value of a variable that was never declared
    
if __name__=="__main__":
    main()
    
    
#Exercise  43-sample file for working with if-else conditional statements
def main():
    x,y=9,8 #define two variables, 
    if(x<y): #see out condition is not met,hence the flow of program goes to else statement
        st="x is less than y" #This variable
    else:#The else condition a takes care of any other outcomes you want to print, apart from if conditions
        st="x is greater than y"
    print(st)#Hence prints 
    
if __name__=="__main__":
    main()
    
    
#Exercise  44-sample file when if-else conditional statements won’t work logically
def main():
    x,y=8,8 #define two variables, 
    if(x<y): #see out condition is not met,hence the flow of program goes to else statement
        st="x is less than y" #This variable
    else:#The else condition a takes care of any other outcomes.But the equal to logic is not catered for
        st="x is greater than y"
    print(st)#Hence prints 
    
if __name__=="__main__":
    main()
    
#Exercise  45-sample file for working with elif conditional statements

def main():
    x,y=8,8 #define two variables, 
    if(x<y): #see out condition is not met,hence the flow of program goes to else statement
        st="x is less than y" #This variable
    elif(x==y):
        st="x is equal to y" #This takes care of the equal to logic
    else:#The else condition a takes care of any other outcomes.
        st="x is greater than y"
    print(st)#Hence prints  

if __name__=="__main__":
    main()
    
#Exercise 46-Execute conditional statements with minimal code
def main():
	x,y = 10,8 #Define two variables
	st = "x is less than y" if (x < y) else "x is greater than or equal to y" #A If B else C
	print(st)
	
if __name__ == "__main__":
	main()

    
#Exercise 47- working with Nested if conditional statements
total = 100
#country = "Kenya" # uncomment or comment this line
country = "Tanzania" #comment or uncomment this line
if country == "Kenya":
    if total <= 50:
        print("Shipping Cost is  Ksh.50")
elif total <= 100:
        print("Shipping Cost is Ksh.20")
elif total <= 150:
	    print("Shipping Costs Ksh.10")
else:
        print("FREE")
if country == "Tanzania": 
	  if total <= 50:
	    print("Shipping Cost is  Ksh.100")
else:
	    print("FREE")
        

    