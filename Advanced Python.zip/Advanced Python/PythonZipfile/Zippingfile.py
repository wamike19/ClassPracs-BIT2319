#Creating a File 
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","w+")#"w" letter in our argument, indicates write and the plus sign that means it will create a file if it does not exist in library.
    for i in range(10):#loop over a range of ten numbers
        f.write("This is line %d\r\n" % (i+1))#declare the output to iterate in the file,put the integer in a carriage return and a new line character
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319

#Exercise 32-creating a zip file
import shutil
from os import path
from zipfile import ZipFile
from shutil import make_archive #import the make archive class,from module shutil

def main():
    if path.exists("BIT2319.txt"):#make a duplicate of existing file
        src=path.realpath("BIT2319.txt");#get the path to the file in the current directory
        
        root_dir,tail=path.split(src)#separate directory from file
        shutil,make_archive("BIT2319 ArchiveFile","zip",root_dir)#create a archive file in zip format, then pass contents of root directory to be zipped
        
    
if __name__=="__main__":
    main()#See an output 

#Exercise 33-creating a zip file for a particular file
import shutil
from os import path
from zipfile import ZipFile#This module gives full control over creating zip files
from shutil import make_archive #import the make archive class,from module shutil

def main():
    if path.exists("BIT2319.txt"):#make a duplicate of existing file
        src=path.realpath("BIT2319.txt");#get the path to the file in the current directory
        
        #root_dir,tail=path.split(src)#separate directory from file
        #shutil,make_archive("BIT2319 ArchiveFile","zip",root_dir)#create a archive file in zip format, then pass contents of root directory to be zipped
with ZipFile("myspecificfileziptest.zip","w") as newzip:#create a new zip file, and pass it write permission
    newzip.write("BIT2319.txt")    #newzip references the new zip file created, which we add specific files for archiving
    
if __name__=="__main__":
    main()#See an output     