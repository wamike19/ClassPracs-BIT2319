#Building Naive Bayes Classifier in Python
# Read https://www.machinelearningplus.com/predictive-modeling/how-naive-bayes-algorithm-works-with-example-and-full-code/

#Import the packages for
from sklearn.naive_bayes import GaussianNB #The Naive Bayes modeling library
from sklearn.model_selection import train_test_split #separating the iris flowers dataset into 1.) training and testing sets

from sklearn.metrics import confusion_matrix#Ignore this for now.But is used for evaluation of accuracy
import numpy as np #This is for arrays manipulation
import pandas as pd #This is for dataset manipulation
import matplotlib.pyplot as plt #This is a plotting library
import seaborn as sns; sns.set()#This is a plotting Library

# Import data

import pathlib

print("Use pandas to read the training and testing sets data")

#Get the data through a 
training = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/iris_train.csv')
test = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/iris_test.csv')




# Create the X, Y, Training and Test
xtrain = training.drop('Species', axis=1)
ytrain = training.loc[:, 'Species']
xtest = test.drop('Species', axis=1)
ytest = test.loc[:, 'Species']



# Init the Gaussian Classifier
model = GaussianNB() #This is a Naive Bayes classifier that starts by first randomizing the imput data

# Train the model 
model.fit(xtrain, ytrain) #This model shall remember historical variables observations of flower patterns

# Predict Output 
pred = model.predict(xtest)#Make a new prediction using the new uobserved variables

# Plot Confusion Matrix
mat = confusion_matrix(pred, ytest)
names = np.unique(pred)

#This is a prediction algorithm for drawing accuracy values
sns.heatmap(mat, square=True, annot=True, fmt='d', cbar=False,
            xticklabels=names, yticklabels=names)
plt.xlabel('Truth')
plt.ylabel('Predicted')