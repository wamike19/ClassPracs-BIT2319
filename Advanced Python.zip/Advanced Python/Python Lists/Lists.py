#Examples of homogeneous lists
#list of integers =  [1, 2, 3, 8, 33]
#list of animals = ['dog', 'cat', 'goat']
#list of names = ['John', 'Travis', 'Sheila']
#list of floating numbers = [2.2, 4.5, 9.8, 10.4]

#Examples of heterogeneous lists
#hetero=[2, 'cat', 34.33, 'Travis']
#[2.22, 33, 'pen']

animals = ['dog', 'cat', 'goat']
hetero=[2, 'cat', 34.33, 'Travis']
listo = [3, 22, 30, 5.3, 20]
subjects = ['physics', 'chemistry', 'mathematics']
integerss = [2, 5, 9, 20, 27]

def main():
    print("We look at some lists here")
    
    
main() #Note how we call python code from the main function
print("An example of homogenous list")
print(animals)

print("An example of heterogenous list")
print(hetero)

print("Accessing values withing a list")
print(listo)

print("Accessing the last value withing a list")
print(listo[-1])

print("List slicing")
print(listo[:])#Show all
print(listo[1:3]) #Show indexes 1 -3,Note how Python lists are upper-bound exclusive
print(listo[:4])#show all upto index four
print(listo[2:-1])#show from index 2 to last index

print("Updating strings in lists")
print(subjects)#Get the original list

subjects[0] = 'biology' #replace physics with biology
print(subjects) #Get the new list

print("Updating integers in lists")
print(integerss)#Get the original list

integerss[-1] = 30.5 #replace 27 with 30.5
print(integerss) #Get the new list

#Exercise 19- list methods

integerss = [3, 5, 7, 8, 9, 20] 
animals = ('cat', 'dog', 'fish', 'cow')
values = [2, 5, 7, 9]
#valuess = [1, 7, 9, 3, 5]

def main():
    print("We look at some lists here")
    #der= del integerss[1] #???
    
main() #Note how we call python code from the main function
print("An example of homogenous list")
print(integerss)   
print("To remove third index  item from the list, using three main methods")



print("using pop, remove index 3:", integerss.pop(3))
print(integerss)

#print("using del operator", der)

print("Appeding element at the end of list items", integerss.append(3.33))
print(integerss)

print("Getting list length",len(integerss))#list length method

print("Getting maximum value in the list",max(integerss)) #list max method

print("Getting minimum value in the list",min(integerss)) #list min method

print("converting a tuple into a list")
print(animals)
print(list(animals))


#print("using remove to get out idex 0 item:", values.remove(0)) #confirm this
print("original order of values is:", values)
values.reverse()
print("Reverse order of values is:",values)

print("To sum all the values in the list")
sum_of_values = sum(values)
print(sum_of_values)




#Exercise20 -  sorting list items
valuess = [1, 7, 9, 3, 5]
strings = ['cat', 'mammal', 'goat', 'is']#strings of list items
def main():
    print("We look at some lists here")
    #der= del integerss[1] #???
main()    
print("To sort list values ")
print(valuess)
print("Ascending order",valuess.sort())#In ascending order
print(valuess)
print("Descending order:",valuess.sort(reverse = True))#In descending order
print(valuess)

print(strings)
print("sorting strings by alphabet:", strings.sort())
print("sorting strings by length:", strings.sort(key = len))

#Exercise 21-Looping through lists
listi = [10, 20, 30, 40, 50, 60, 70]
list2 = [10, 20, 30, 40, 50, 60, 70]
def main():
    print("my initial list items are:", listi)

main()
print("Now we see looping function to add 5 to each element")
for elem in listi:
        elem = elem + 5
        print(elem)
        
print("loop through the first three elements of the list, and delete all of them")
for elem in listi[:3]:
    listi.remove(elem)
    print(listi)
    
new_list = []
print('Original list is: {}'.format(list2))#Note here you cant use "" 
for elem in list2[2:]:#from third index
    new_list.append(elem)
    print('New List: {}'.format(new_list)) #Note here you cant use ""   


#Exercise 22-List comprehension
list_of_squares = []
def main():
    for int in range(1, 10):
        square = int ** 2
        list_of_squares.append(square) #create a new list with square values
        #print(list_of_squares)#NOTE . If we call print here, the function is called many times
main()  

print("Using for loop:", list_of_squares)#Here the function is called ones

    

list_of_squares = []
def main():
    list_of_squares_2 = [int**2 for int in range(1, 10)]#with list comprehensions    
main()  
#print("Using list comprehension:",list_of_squares_2 )
print('List of squares using list comprehension: {}'.format(list_of_squares_2))
    

#Task: Learn about using enumerated, lambda, map functions in python



    