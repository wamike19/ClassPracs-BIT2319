# Exercise 15- Writing and assignning value to an empty Tuple
tup1 = ();

Tup1 = (50,);# Note you need to write semicolon at the end


#Exercise 16-Tuple Assignment
tup1 = ('Selina', 'Nyamboku','1999','BBIT 3.1', 'Student','DeKUT');#(name, surname, birth year, course and year of study, profession, placeofwork) = Selina

tup2 = (1,2,3,4,5,6,7);
print(tup1[0]) #show list item of information about Selina
print(tup2[1:4])#show a list of numbers in the tuple

#Exercise 17-Tuple packing and unpacking
x = ("DeKuT", 20, "Education")    # tuple packing, by adding elements
(company, emp, profile) = x    # tuple unpacking by describing the tuple elements
print(company)
print(emp)
print(profile)


#Exercise 18-Comparing Tuples,Comparison starts with a first element of each tuple.
a=(5,6)
b=(1,4)
if (a>b):print("a is bigger")#  In this case 5>1
else: print("b is bigger") #This evaluates the elements is the first two tuples, and prints out the bigger tuple
    
    
    
a=(5,6)
b=(5,4)
if (a>b):print("a is bigger")#Note,in this case 5>5 which is inconclusive. So it proceeds to the next element. 6>4, so the output a is bigger 
else: print ("b is bigger")#This evaluates the elements is the two tuples, and prints out the bigger tuple
    
    
a=(5,6)
b=(6,4)
if (a>b):print("a is bigger")#In this case 5>6 which is false. So it goes into the else loop prints "b is bigger." 
else: print("b is bigger")#why is b bigger than a here??Rember a tuple is a record
    
    
#Exercise 19- Wrong Using Tuples as keys in the dictionary   
directory[last,first] = number
for last, first in directory:
    print (first, last, directory[last, first])
    


#Exercise 20-Tuples and Dictionary
a = {'x':100, 'y':200} #This are record elements assigned in a dictionary
b = list(a.items()) #tuples
print(b) 


#Exercise 21 - fetch specific sets of sub-elements from tuple or list
x = ("a", "b","c", "d", "e")
print(x[2:4])#fetch elements begining with index 2 and not beyong index 4














    
    