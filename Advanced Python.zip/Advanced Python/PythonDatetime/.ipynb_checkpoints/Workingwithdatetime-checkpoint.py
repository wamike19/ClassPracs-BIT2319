from datetime import date
from datetime import time
from datetime import datetime

def main():
    today=