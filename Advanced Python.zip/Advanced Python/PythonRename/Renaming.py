#Creating a File 
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","w+")#"w" letter in our argument, indicates write and the plus sign that means it will create a file if it does not exist in library.
    for i in range(10):#loop over a range of ten numbers
        f.write("This is line %d\r\n" % (i+1))#declare the output to iterate in the file,put the integer in a carriage return and a new line character
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319
    
    
#Exercise 32-Renaming files 
import os  
from os import path

def main():
    if path.exists('BIT2319.txt'):#make a duplicate of the existing file
        src=path.realpath('BIT2319.txt');
        os.rename('BIT2319.txt','BBIT.txt') #Rename the original file
        
if __name__=="__main__":
    main()#See an output BBIT file    