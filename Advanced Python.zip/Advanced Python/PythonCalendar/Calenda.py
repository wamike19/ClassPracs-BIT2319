#Exercise 16-Using the calendar class
import calendar #import classes for this module
c=calendar.TextCalendar(calendar.SUNDAY) #ells the interpreter to create a text calendar; where start of month is sunday
str=c.formatmonth(2025,1) #create a plain text calendar for year 2025,jan
h=calendar.HTMLCalendar(calendar.MONDAY)#Create a html calendar
strr=h.formatmonth(2020,1)
print("Text string calendar")
print(str)
#print("HTML calendar") #uncomment to see
print(strr)

for i in c.itermonthdays(2025,1):
    print(i)#you will see today days of month and also see some zeros along with these days at the beginning and sometimes at the end of it. That is,the week is in an overlapping month, which means it does not belong to that month.
    
for name in calendar.month_name:
    print(name)#getting data from the local system,printed out the months name from the local system. 
    
for day in calendar.day_name:#output as per the local settings of that country.
    print(day)#getting data from the local system

#Exercise 17-Fetch a list of specific day
import calendar
for month in range(1,13):
    mycal=calendar.monthcalendar(2025,month)#create a calendar for the month
    week1=mycal[0] #set variable for first week on month
    week2=mycal[1]#set variable for second week on month
    
    if week1[calendar.MONDAY]!=0:#we use the calendar constant MONDAY
        auditday=week1[calendar.MONDAY]#if monday starts in the first week
    else:
        auditday=week2[calendar.MONDAY] #f monday starts in second week
    print("%10s %2d"%(calendar.month_name[month],auditday))#Get a list for first monday of every month
    
        
            
    
