#Creating a File 
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","w+")#"w" letter in our argument, indicates write and the plus sign that means it will create a file if it does not exist in library.
    for i in range(10):#loop over a range of ten numbers
        f.write("This is line %d\r\n" % (i+1))#declare the output to iterate in the file,put the integer in a carriage return and a new line character
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319
    

    
#Exercise 30-Copy file in python    
import os
from os import path
import shutil #import the system utilities,#use Shutil Module to create a copy of the existing file.

def main():
    if path.exists("BIT2319.txt"):#check that our "BIT2319.txt" file exists or not
        src=path.realpath("bit2319.txt")#store the file path in the variable "src" if your file exist
    
    head,tail=path.split(src)# get the path, then separate the path and the file name
    print("path:" +head)#prints out "file path" separately 
    print("path:"+tail)#prints out "file name" only 
    
    #we can make a backup copy by appending .back to the souce file
    dst=src+".bak"#taking the orginal .txt file,add letters .bak at the end to get a duplicate copy
    shutil.copy(src,dst)#use utility's copy function to copy from source to the destination
    shutil.copystat(src,dst)#copy all information related to the file such as permission,modification time and metadata
    
if __name__=="__main__":
    main()#See an output folder/directory PythonCopyFile
    
#Exercise 31-Fetch file information
import os
from os import path
import datetime
from datetime import time#date,timedelta
import time


def main():
    t=time.ctime(path.getmtime("BIT2319.txt"))# get the day,month,year and time when the file was last modified
    print(t)
    print(datetime.datetime.fromtimestamp(path.getmtime("bit2319.txt.bak")))#Use a different format from previous one

if __name__=="__main__":
    main()
    