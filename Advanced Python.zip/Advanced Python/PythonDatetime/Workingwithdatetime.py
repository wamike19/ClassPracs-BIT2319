
# Exercise 7-Using the date class
from datetime import date
from datetime import time
from datetime import datetime

def main():
    today= date.today()#assigning the value of the current date to the variable today
    print("Today's date is",today.day, today.month, today.year)
    
if __name__=="__main__":
        main()
    
    
    
# Exercise 8-Getting the day of the week
from datetime import date
from datetime import time
from datetime import datetime

def main():
    today= date.today()#assigning the value of the current day to the variable today
    print("Today's date is",today.weekday())
    #Days start at 0 for monday
    wd=date.weekday(today)#weekday returns 0 (monday) through 6 (sunday)
    days= ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
    print("Today is day number %d" % wd)
    print("which is a " + days[wd])
    
if __name__=="__main__":
    main()    
        
        
            
# Exercise 9- Getting today’s time
from datetime import datetime
def main():
    today=datetime.now()
    time=datetime.time(datetime.now())#assigning the value of the current time to the variable time
    print("The current date and time is:",today) #Show date and time
    print("The current  time is:",time)   #show time only 
    
if __name__=="__main__":
    main()  
    
    
#Exercise 10-Formatting the time object
from datetime import datetime
def main():
    now=datetime.now()#get the currect date and time
    print("Year is ", now.strftime("%Y"))
    print("OR", now.strftime("%y"))
    print("Month is",now.strftime("%B"))#or "b
    print("Day of month is", now.strftime("%D"))# or d
    print("Weekday is", now.strftime("%A"))#or "a"
if __name__=="__main__":
    main()     
    

    
#Exercise 11-Formatting the time string objects into a normal date format
from datetime import datetime
def main():
    now=datetime.now()#get the currect date and time
    print(now.strftime("%a,%d %B,%y"))#day,date,month,year
    
if __name__=="__main__":
    main() 
    
    
#Exercise 12- Using strftime to retrieve local time    
from datetime import datetime
def main():
    now=datetime.now()#get the currect date and time    
    print(now.strftime("%c")) #get local date and time
    print(now.strftime("%x"))#get local time
    print(now.strftime("%X"))#get local time of native system
    print(now.strftime("%I:%M:%S %p"))#hour minute second format
    print(now.strftime("%H:%M"))#24 hour minute format
    
if __name__=="__main__":
    main() 
    
#Exercise 13-Using strftime to retrieve time formats 
from datetime import datetime
def main():
    now=datetime.now()#get the currect date and time    
    print(now.strftime("%I:%M:%S %p"))#hour minute second format
    print(now.strftime("%H:%M"))#24 hour minute format
    
if __name__=="__main__":
    main()     
    
#Exercise 14-Using a Timedelta function
from datetime import timedelta
def main():
    print(timedelta(days=365,hours=8,minutes=15))#construct a basic time delta and print it
    print("Today's date is:"+str(datetime.now()))#print  date
    print("One year from now it will be:"+str(datetime.now() +timedelta(days=365)))#project the future
    print("Two weeks from now, it will be:"+str(datetime.now() +timedelta(weeks=2,days=1)))
    
if __name__=="__main__":
    main()                        
    
    
#Exercise 15Using a Timedelta function to find days past new year
from datetime import date
from datetime import time
from datetime import datetime
from datetime import timedelta
def main():
    today =date.today() #get today's date
    nyd = date(today.year, 1, 1)#new year day for the same year.Use date comparison to see if new year date has already gone.

if nyd < today:
    print("The new year already went by %d days ago" % ((today-nyd).days))# the calculation how many days are left or passed after new year
    
if __name__=="__main__":
    main()     
    
    
    
    
    
    
    
    