def main():
    print("Hello world.Welcome to main function territory")
	
main()
print("I am not within the main function territory")

