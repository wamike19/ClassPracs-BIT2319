
# Exercise 49- Class definition 
class myPythonCLass():#define a new class
    def method1 (self): #define a method to print a string.Note 'self'-argument refers to the object itself. 
        print ("This practice is nice")#Here self refers to the specific instance of this object that's being operated on.
    def method2 (self,someString): #define a method which supplies a variable someString
        print ("Software Testing:" + someString)
        


def main():   #Define the main function, outside the class scope        
    objt = myPythonCLass()#Instantiation to make an object of the class 
    objt.method1()#To call a method, using an object
    objt.method2("Testing this software is fun")
  
    if __name__== "__main__":
        main()


#Exercise 50- Working with classes and Inheritance
class myBaseClass():#Define a base class
    def method1(self):
        print("Tres Bien!")
        
class childClass(myBaseClass):#Define a child class, which inherits from the base class
    #def method1(self):#call method in the base class
        myBaseClass.method1(self);#Notice that the in childClass, method1 is not defined but it is derived from the parent myClass. 
        print ("childClass using base Method1")
    def method2(self):
        print("childClass method2")     
         
def main(): # exercise the class methods          
    c2 = childClass() #Create an object of the child class
    c2.method1() #uncomment and watch reaction
    c2.method2() #uncomment and watch reaction

if __name__== "__main__":
    main()


#Exercise 51- Working with Constructors
class User:#Define a class
    name = "" #define a variable
    
    def __init__(self, name):#A constructor to initialize an object user
        self.name = name#get the name value using the constructor

    def sayHello(self):
        print("Welcome to my first constructor in, " + self.name)

User1 = User("BIT 2319")
User1.sayHello() #Call the method using the User1 object
