import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline

#Part 1 -Obtaining Dataset
dataset = pd.read_csv("C:/Users/lab/Downloads/bill_authentication.csv") #Get the data frame

dataset.shape  #See the array dimensions in the data frame 

dataset.head(5)  #Inspect five records in the data frame

#Part Two -divide data into attributes and labels, execute the following code

X = dataset.drop('Class', axis=1)  #Predictor attributes, which drops the last target column
y = dataset['Class']  #Target attributes

#Try X or Y to see outcome
    
#Part Three-divide our data into training and test sets
from sklearn.model_selection import train_test_split  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20)  #test size is 80% trainng and 20% testing

#Try X_train, X_test, y_train, y_test


#Part Four-Training and Making Predictions
#use the DecisionTreeClassifier algorithm for the classification problem
from sklearn.tree import DecisionTreeClassifier  
classifier = DecisionTreeClassifier()  
classifier.fit(X_train, y_train)  #Perfom classifcation bt training the algorithm on the training data

#Part 5-make predictions on the test data
y_pred = classifier.predict(X_test)  #the predict method is used and the test dataset sample
#try y_pred and see outcome

#Part 6 -Evaluating the Algorithm
#commonly used metrics are confusion matrix, precision, recall, and F1 score
from sklearn.metrics import classification_report, confusion_matrix  
print(confusion_matrix(y_test, y_pred))   #see the output of true positives,false positives,true negatives and false negatives

print(classification_report(y_test, y_pred))  #get prediction accuracy






