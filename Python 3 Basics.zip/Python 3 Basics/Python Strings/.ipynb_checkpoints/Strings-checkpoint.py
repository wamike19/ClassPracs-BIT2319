
#Exercise 6-Accessing string values 
var1 = "We all know python!"
var2 = "Software Testing"
print ("var1[0]:",var1[0])#print string element of the 1st index.Note index elements beging from 0 position
print ("var1[1]:",var1[1])#print string element of the 2nd index
print ("var2[1:8]:",var2[1:8]) #print contents between these string elements


#Exercise 7-Various string operators

#showing a index element/ character in a string
x="Guru wa python"
print (x[0])
print (x[2]) #The operator square brackets is used to slice s string by giving a letter from the given string index
print(x)#This prints everything


#showing a range of index  elements/ characters in a string
x="Guru wa python"
print (x[0:3]) #see where we start counting indexes from
print (x[2:4]) #see a space is a string element in the array

#showing a membership in elements/ characters exist in a string
x="Guru wa python"
print ('u' in x) #see it evaluates(True or False) the presence of a  character u in the string


#showing a not in membership in elements/ characters of a string
x="Guru wa python"
print ('s' not in x)#return True if 'a letter s does not exist'in the given string


# How a raw string suppresses actual meaning of escape characters. 
x="Guru wa python"
print (r'\n')#Just prints the character n, instead of doing the escape sequence
print('\n')#This prints the new line escape sequence 
print (R'/n')

#Perfoming string formating using percentage symbol
name = 'Artificial Intelligence'
number = 3.1 #This is a float value
print('%s %d' % (name,number)) #string and number
print('%s %f' % (name,number)) #string and float


#concanating two strings
x="something "
y= "is wrong here"
print (x) #print as is
print (x+y)


#Repeat  by printing a character twice
x="Artificial Intelligence" 
y="3" 
print (x) #print as is
print (x*2)#This prints the contexts of variable x twice

#Exercise 8- updating a python String by re-assigning a variable to another string.
x = "Hello class!"
print(x[:6]) 
print(x[0:6] + "IT3.1")#This adds more string elements from the last three index elements a #see slice:6 or 0:6 has the same effect 

#Exercise 9-Replacing a string with another copy

oldstring = 'I like Machine Learning' 
newstring = oldstring.replace('like', 'love')

print(oldstring)#print the old string
print(newstring)#print the new string


#Excersise 10- Changing from lower to upper case and vise versa, and to capital

string1="python is now my favourite A.I programming language "
print(string1.upper())#changing to upper case

string2="I AM NOT NERVOUS AGAIN "
print(string2.lower()) #changing to lowercase

string3="python is fun"		
print(string3.capitalize())#doing capitalization


#Exercise11-Joining strings, using the joing function

print(":".join("Artificial "))	#Add a full colon after every character

#Execise 12-Reversing a string
string="123456789"		
print(''.join(reversed(string)))

#Exercise 13-splitting string sentence into individual words
word="My A.I practical lesson is fun"		
print(word.split(' ')) #separate the sentence into different words
print(word.split('c')) #separate the sentence along the character c


#Exercise 14-Replacing string items
x = "I am Weak in A.I but strong in Python"
y= x.replace("Weak in A.I but strong in","Strong in A.I Practicals using")#Replace a sentence segment
z= x.replace("Weak in A.I but strong in"," ")#Replace a sentence segment
print(x)#Note this does not output the new value of x variable
print(y) #the new values are assigned a different variable and then printed
print(z)














