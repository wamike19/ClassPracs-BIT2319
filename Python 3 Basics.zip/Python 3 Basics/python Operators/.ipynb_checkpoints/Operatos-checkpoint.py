#Exercise 31- Arithmetic Operators
x= 10	
y= 5
print("For addition x+y ", x + y) #Addition
print("For addition x-y ",x - y) #Subtraction
print("For addition x*y ",x * y) #Multiplication
print("For addition x/y ",x / y) #Division

#Exercise 32-Comparison Operators

x= 8 #You can change the values here and watch the reactions	
y= 5
print("For Greater than x > y", x > y) #Greater than
print("For Greater or equal to x >=y ", x >=y) #Greater or equal to
print("For Less than x < y ",x < y) #Less than
print("For Less that or equal to x <= y",x <= y) #Less that or equal to
print("For equal to x == y",x == y) #Not equal to
print("For Not equal to x != y",x != y) #Not equal to

#Exercise 33- Python Assignment Operators
num1 = 4
num2 = 5
print(("Value of num1 : ", num1))
print(("Value of num2 : ", num2))

#Second case, of a complex expression
num1 = 4
num2 = 5 #Assign value to num1 and num2 
res = num1 + num2 #Perfom addition i.e. Add value of num1 and num2 (4+5=9)
res += num1 #To this result add num1 to the output of Step 2 ( 9+4)
print(("The final result of += is ", res)) #print the final result i.e. 13 

#Exercise 34-Logical Operators
a = True
b = False #Change this value to True and see the outcome

print(('a AND b is',a and b))
print(('a OR b is',a or b))
print(('NOT a is',not a))

#Another example
a = 1 #Change this value to 0 and see the outcome
b = 0 #Change this value to 1 and see the outcome

print(('a AND b is',a and b))
print(('a OR b is',a or b))
print(('NOT a is',not a))
#Find more examples to evaluate complex expressions


#Exercise 35-Membership Operators
#You can imaging yourself doing an interactive search with a real input values
x = 4 
y = 8 #Declare the value for x and y 
list = [1, 2, 3, 4, 5,12,22,31 ];#Then declare the values of list
if ( x in list ):#Then use the "in" operator in code with if statement to check the value of x existing in the list and print the result accordingly
   print("First evaluation found, x is available in the given list")
else:
   print("First evaluation found, x is not available in the given list")
if ( y not in list ):#Or use the "not in" operator in code with if statement to check the value of y exist in the list and print the result accordingly
   print("Second evaluation found, y is not available in the given list")
else:
   print("Second evaluation found, y is available in the given list")#Get the desired output



#Exercise 36-Using Identity Operators
x = 20 #Declare the value for variable x 
y = 20 #Declare the value for variable  y
if ( x is y ): #check if value of x is same as y. This is what helps to perfom pattern matching/recognition;BUT in a large matrix
	print("The values of x & y  have SAME identity")
y=30 #Re-declare the value for variable x and y
if ( x is not y ):# check if value of x is not same as y
	print(" Now the values of x & y have DIFFERENT identity")


#Exercise 37-Operator precedence
#First declare the value of variable v,w…z
v = 4
w = 5
x = 8
y = 2
z = 0
z = ((v+w) * x / y);   #Now apply the formula and run the expression to calculate the variable with higher precedence 
print("Value of (v+w) * x/ y is ",  z) #The expected output is 36



