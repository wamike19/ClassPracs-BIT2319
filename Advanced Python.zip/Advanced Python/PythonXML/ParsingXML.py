#Exercise 35- Parsing an xml file
import xml.dom.minidom
from os import path 

def main():
    print ("File  exist:"+str(path.exists('myfilesample.xml')))#This file is present
    doc = xml.dom.minidom.parse("myfilesample.xml");#load and parse and xml file
    
    print(doc.nodeName)#print the node name from the xml file
    print(doc.firstChild.tagName)#print first child tagname i.e. employee from the xml file
    
    expertise = doc.getElementsByTagName("expertise") #Declare the variable expertise, from which we going to extract all the expertise name employee is having.Then use  the dom standard function getElementsByTagName to 
    print("%d expertise:" % expertise.length)#get all elements named skill
    for skill in expertise:#declare a loop over each f the skill tags
        print(skill.getAttribute("name"))#get a list of xml tags from the document and print each
    
if __name__=="__main__":
    main()
    
    
#Exercise 36-creating new xml node
import xml.dom.minidom
from os import path 

def main():
    print ("File  exist:"+str(path.exists('myfilesample.xml')))#This file is present
    doc = xml.dom.minidom.parse("myfilesample.xml");#load and parse and xml file
    
    print(doc.nodeName)#print the node name from the xml file
    print(doc.firstChild.tagName)#print first child tagname i.e. employee from the xml file
    
    expertise = doc.getElementsByTagName("expertise") #Declare the variable expertise, from which we going to extract all the expertise name employee is having.Then use  the dom standard function getElementsByTagName to 
    print("%d expertise:" % expertise.length)#get all elements named skill
    for skill in expertise:#declare a loop over each f the skill tags
        print(skill.getAttribute("name"))#get a list of xml tags from the document and print each
    
        
    newexpertise=doc.createElement("expertise")#add a new XML and add it to the document
    newexpertise.setAttribute("name","BigData") #Add attributes Big Data
    doc.firstChild.appendChild(newexpertise)#Add this skill tag into the document first child (employee)
    print("") 
        
    expertise = doc.getElementsByTagName("expertise") #Declare the variable expertise, from which we going to extract all the expertise name employee is having.Then use  the dom standard function getElementsByTagName to 
    print("%d expertise:" % expertise.length)#get all elements named skill
    for skill in expertise:#declare a loop over each f the skill tags
        print(skill.getAttribute("name"))#get a list of xml tags from the document and print each
        
    
if __name__=="__main__":
    main()    
    
    
#Exercise 37-using ElementTree to parse an xml

    
import xml.dom.minidom
from os import path 
import xml.etree.ElementTree as ET

def main():
    print ("File  exist:"+str(path.exists('myfilesample.xml')))#This file is present
    tree = ET.parse('treeData.xml')
    root = tree.getroot()#To fetch the root element i.e. the data is the "node name" of the root of the document
    
    print('Expertise Data:')#To get all items data
    
    for elem in root:
        for subelem in elem:#get the firstchild tagname
            print(subelem.text)
            
    
if __name__=="__main__":
    main()     
    