#Exercise 1-variable declaration
a=100  #declare a variable a
print (a)#print the declared variable

#Exercise 2- how to re-declare the variable even after you have declared it once 
F=0
print(F)
F= 'mchezo tuu'
print(F)

#Exercise 3- concatenation
print('combine word' +100)#will result to TypeError: can only concatenate str (not "int") to str.

#In this code, you will get a type error too
a='my word'
b = 99
print (a+b)#TypeError: can only concatenate str (not "int") to str

#But once the integer is declared a string, things get fine
a='my word'
b = 99
print (a+str(b)) #See, this is the correct way to do string concatenation in python, unlike in Java

#Exercise 4 - Global and Local Variables declation

a=100  #declare a global variable and 
#print (a)# print the declared global variable

#To show global and local variables in a function
def myFunction():
    a='I am having fun learning' #This is a local variable within a function  
    print(a)
    
myFunction() # print the declared local variable
print(a)# print the declared global variable

#Exercise 4.2 - Declaring a global variable within a function
a=102  #declare a global variable and 
print (a)# print the declared global variable

#To show global and local variables in a function
def myFunction():
    global a
    print(a)
    a='I changed the global variable' #This is a local variable within a function  
    #print(a)
    
myFunction() # print the declared global variable
print(a)# print the changed initially declared global variable through keyword global


#Exercise 5 - Deleting a variable
a=103  #declare a global variable and 
print (a)# print the declared global variable

del a #delet the declared variable
print(a) #we get an error,NameError: name 'a' is not defined








    
