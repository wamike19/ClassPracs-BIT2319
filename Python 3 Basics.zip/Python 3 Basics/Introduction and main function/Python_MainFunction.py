def main():
    print("Hello world.Welcome to main function territory")
	
main() #Note how we call python code from the main function
print("I am not within the main function territory")


