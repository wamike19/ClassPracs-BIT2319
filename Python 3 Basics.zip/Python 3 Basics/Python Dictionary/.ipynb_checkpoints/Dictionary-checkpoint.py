#Exercise 22- using a disctionary data structure

Dict = {'Timmothy': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}	
print ("The age of eshikumo is:") 
print (Dict['Eshikumo'])#"The age of eshikumo is:" 

#Exercise 23-copying dictionary items
Dict = {'Timmothy': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25, 'Tabby':20}	#We have the original dictionary (Dict) with the name and age of the boys and girls together

#But we want boys list separate from girls list
Boys = {'Timmothy': 18,'Charles':12, 'Robert':25}#defined the element of boys and girls in separate dictionarys name "Boys" and "Girls."
Girls = {'Tabby':20, 'Jaccky':23}	

#created new dictionary name "studentX" and "studentY", where all the keys and values of boy dictionary are copied into studentX
studentX=Boys.copy()
studentY=Girls.copy()
#you don't have to look into the whole list in main dictionary( Dict) to check who is boy and who is girl, you just have to print studentX if you want boys list and StudentY if you want girls list
print (studentX)
print (studentY)#get all the element present in the dictionary of "girls" separately
print(Dict)#get all elements in the original dictionary


#Excercise 24-Updating dictionary
Dict = {'Kioko': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}
print("Before updating  Sarah")
print(Dict)
Dict.update({"Sarah":9})#Add sarah to the dictionary
print("after updating sarah")
print(Dict)


#Exercise 25-Deleting key elements in a dictionary
Dict = {'Kioko': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}		
print("Before deleting an element")
print(Dict)
del Dict ['Tom']
print("After deleting Tom")
print(Dict)


#Exercise 26- Using items method in a dictionary
Dict = {'Kioko': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}
print("Students Name: %s" % list(Dict.items()))

#Exercise 27-Check if a key already exists in a large dictionary
#For the boys
Dict = {'Kioko': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}#Assume Kioko is in a facebook radicalization site
Boys = {'Kioko': 18,'Charlie':12,'Robert':25}#Also assume the police have 3 boys in a wanted list of suspects
Girls = {'Tiffany':22}#Also assume the police have 1 girl in a wanted list of suspects

print("Scan with our boys mini-dictionary found")#It indicates that two "Boys" exist in our main dictionary (Dict)
for key in list(Dict.keys()):#The for loop in code checks each key in the main dictionary for Boys  keys
    if key in list(Boys.keys()):
        print(True)#Return True if check if all the Boys in mini dictionary exists in the main dictionary
    else:       
        print(False)#Otherwise return false
        
        
     
        
#For the girls       
Dict = {'Kioko': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}#Assume Kioko is in a facebook radicalization site
Boys = {'Kioko': 18,'Charlie':12,'Robert':25}#Also assume the police have 3 boys in a wanted list of suspects
Girls = {'Tiffany':22}#Also assume the police have 1 girl in a wanted list of suspects
print("Scan with our girls mini-dictionary found")
for key in list(Dict.keys()):
    if key in list(Girls.keys()):
        print("Our girls scan found")
        print(True)#Return True if check if the Boys mini dictionary exists in the main dictionary
    else:       
        print(False)#Otherwise return false        
        
        
#Exercise 28-Sorting Items in a Dictionary
Dict = {'Kioko': 18,'Charles':12,'Tom':22,'Robert':25,'Eshikumo':25}#Assume Kioko is in a facebook radicalization site
Students = list(Dict.keys()) #declare a variable students in the dictionary
Students.sort() #the sort the list elements
for S in Students:#declare a variable S, to call each element from the dictionary and print them in a sorted order
      print(":".join((S,str(Dict[S]))))
        
        
        
        
        