#Exercise 52- Using While Loops

def main():
	x=0# set an initial condition in the test variable
	
	while(x < 10):#define a while loop, with a stop condition value
		print(x)
		x = x+1#increament operation

if __name__ == "__main__":
    main()
    
#Exercise 53-Using For Loops

def main():
	x=0
for x in range(3,10):#Define a for loop , which MUST also declare a range
		print(x)#print the number between 3 and 10


if __name__ == "__main__":
    main()
    
    
#Exercise 54-Using For Loops with strings
def main():
	Months = ["Jan","Feb","Mar","April","May","June"]#use a for loop over a collection to store months in variable m
	for m in Months:#Iterate over each list element 
		print(m)#Print the variable contents.
		
if __name__ == "__main__":
	main()
    
    
#Exercise 55- How to use break and continue statements in For Loop
def main():
    x=0
for x in range(3,20):#Define a for loop , which MUST also declare a range
    #if (x == 15): break #terminate at number 15 and stop executing
    if (x % 2 == 0): continue #terminate the current iteration of the for loop BUT will continue execution of the remaining iterations. The condition is get numbers that are NOT divisible by 5
    print(x)#print the number between 3 and 10


if __name__ == "__main__":
    main()
    
