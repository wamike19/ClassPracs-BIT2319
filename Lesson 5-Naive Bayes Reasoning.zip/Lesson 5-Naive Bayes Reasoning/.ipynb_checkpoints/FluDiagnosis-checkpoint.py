import numpy as np
from collections import Counter, defaultdict

#Section B -calculating the prior probabilities of the two classes using a dictionary
def occurrences(list1):
    no_of_examples = len(list1)
    prob = dict(Counter(list1))
    for key in prob.keys():
        prob[key] = prob[key] / float(no_of_examples)
    return prob

#Section C  - count the occurrences of the features class-wise
def naive_bayes(training, outcome, new_sample):
    classes     = np.unique(outcome)
    rows, cols  = np.shape(training)
    likelihoods = {}
    for cls in classes:
        likelihoods[cls] = defaultdict(list)#Separate vectors of the two classes
  
    class_probabilities = occurrences(outcome) #
    #print(class_probabilities)#You can run this to see output

#Section D- Calculate probabilities per class and per feature  
    for cls in classes:#taking samples of only 1 class at a time
        row_indices = np.where(outcome == cls)[0]
        subset      = training[row_indices, :]
        r, c        = np.shape(subset)
        for j in range(0,c):
            likelihoods[cls][j] += list(subset[:,j])
  
    for cls in classes:
        for j in range(0,cols):
             likelihoods[cls][j] = occurrences(likelihoods[cls][j])
#Section E-Find class of previously unseen example
    results = {}
    for cls in classes:
         class_probability = class_probabilities[cls]
         for i in range(0,len(new_sample)):
             relative_values = likelihoods[cls][i]
             if new_sample[i] in relative_values.keys():
                 class_probability *= relative_values[new_sample[i]]
             else:
                 class_probability *= 0
             results[cls] = class_probability
    print (results)#See the outcomes, meaning this patient has no flu is more likely than having a flu

#Section A - Building the training data. Eight lists records with four column entries    
if __name__ == "__main__":
    training = np.asarray(((1,0,1,1),
                           (1,1,0,0),
                           (1,0,2,1),
                           (0,1,1,1),
                           (0,0,0,0),
                           (0,1,2,1),
                           (0,1,2,0),
                           (1,1,1,1)));
#What outcomes do we expect
    outcome = np.asarray((0,1,1,1,0,1,0,1)) #The outcome is flu=0, and no flu =1
    new_sample = np.asarray((1,0,1,0)) #A new patient's symptoms

naive_bayes(training, outcome, new_sample)#Calcumate the probability using Naive Bayes model
