#Exercise 38- Defining functions
def func1():
    print("Python functions are easy to define")
    
print (func1()) #This calls our def func1(): and print the command


#Exercise 39-Defining return function
def square(x):#Here x means the square math function expects an input value
    print(x*x)#This function computes and gives 16
    
print(square(4))#Input a parameter and call a square function, BUT  without a return method


#see again
def square(x):#Here x means the square math function expects an input value
    y=x*x#This function computes and gives 16, but cant print
    
print(square(4))#When you run the command "print square (4)" it actually returns the value of the object x, without computing the square

#But now we define a return

def square(x):#Here x means the square math function expects an input value
    return x*x#This function computes and retruns  16, which will be printed out
    
print(square(4))#The return command returns the value of the function i.e. square of 4

#Exercise 40-Return function as an object
def square(x):
    return x*x
print(square)#Returns <function square at 0x0000000005A34488>


#Exercise 41-Declaring arguments in function definitions

def multiply(x,y):#defining inputs arguments for function multiply
    print (x*y)

#multiply(x,y) #Call the function, and dont pass its real parameters
multiply(2,4) #Call the function, and pass its parameters

#41.1 Another case
def multiply(x,y=5):#defining inputs arguments for function multiply
    print (x*y)

#multiply(x,y) #Call the function, and dont pass its real parameters
multiply(2)#See here we ommitted y, because its value is already initialized

#41.2 changing the order of arguments
def multiply(x,y):#see this order change
    print ('value of x =',x)
    print('value of  y=',y)
    return x*y

print(multiply(y=2, x=4))#note the change of ordering of passed arguments

#41.3 -Passng multiple arguments
args=(1,2,3,4,5,6,7,8,9)
def showme(args):#defining inputs arguments for function multiply
    print (args)
showme(args) #This function obtains the multiple parameters and runs the print function to display them

    
    