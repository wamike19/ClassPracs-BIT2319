#Exercise 23-Creating a File 
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","w+")#"w" letter in our argument, indicates write and the plus sign that means it will create a file if it does not exist in library.
    for i in range(10):#loop over a range of ten numbers
        f.write("This is line %d\r\n" % (i+1))#declare the output to iterate in the file,put the integer in a carriage return and a new line character
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319
    
#Exercise 24-Appending to a file 
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","a+")#"w" letter in our argument, indicates append and the plus sign that means it will create a file if it does not exist in library.
    for i in range(5):
        f.write("Appended line %d\r\n" % (i+1))
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319

#Exercise 25-Reading from a file 
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","r")#"r" letter in our argument, indicates read mode
    if f.mode == 'r':#check if the file is open
        contents =f.read()#Here,read file data and store it in variable contents
        print (contents)#This prints out the read contents
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319    
    
#Exercise 26-Reading from a file line by line
def main(): #create a variable f, to open a file name.txt
    f= open("BIT2319.txt","r")#"r" letter in our argument, indicates read mode
    if f.mode == 'r':#check if the file is open
        fL=f.readlines()#This reads a document line by line
        for x in fL:
            print (x)#This prints out the read line contents
    f.close() #close the file instance
    
if __name__=="__main__":
    main()#See an output text file called BIT2319     
    
    
#Exercise 27-Check if OS path exists
import os.path
from os import path #This must be imported

def main():
    print ("File 1 exist:"+str(path.exists('BIT2319.txt')))#This file is present
    print ("File 2 exists:" + str(path.exists('career.guru99.txt')))
    print ("Directory exists:" + str(path.exists('myData')))#Check this is true if we add a datafile called myData

if __name__== "__main__":
    main()

    
#Exercise 28-Check if isFile path    
import os.path
from os import path

def main():

	print ("Is it File?" + str(path.isfile('BIT2319.txt')))#This will be true
	print ("Is it File?" + str(path.isfile('myData')))#This will be false
if __name__== "__main__":
	main()    

#Exercise 29-Check if path points to a directory
import os.path
from os import path

def main():
    print ("Is it Directory?" + str(path.isdir('BIT2319.txt')))#This is a file,not a directory
    print ("Is it Directory?" + str(path.isdir('myDATA')))#check the case does not matter

if __name__== "__main__":
    main()

#Exercise 29-using a pathlib to check if file exists
import pathlib
file = pathlib.Path("BIT2319.txt")
if file.exists ():
    print ("Yes, File exist")
else:
    print ("Noo, File not exist")

    