#A program to demonstrate the working of the decision tree based ID3 algorithm,
import pandas as pd

#Part 1:-Preparing your training dataset samples
df = pd.read_csv('PlayTennis.csv') #Using a play tennis data set for building the decision tree and applying this knowledge to classify a new sample.
print("\n Input Data Set is:\n", df) #see the data frame output 


t = df.keys()[-1] # Next we get the attribute names from input dataset
print('Target Attribute is: ', t)

attribute_names = list(df.keys()) # We want to remove the target attribute from the attribute names list,because it is not important as prediction variables

attribute_names.remove(t) #Here we remain with prediction attributes/columns only
print('Predicting Attributes: ', attribute_names)


#Part 2 -Computing Entropy
import math
def entropy(probs):  #Add function to calculate the entropy of collection S
    return sum( [-prob*math.log(prob, 2) for prob in probs])


def entropy_of_list(ls,value):  #Add function to calulate the entropy of the given Data Sets/List with respect to target attributes
    from collections import Counter
    cnt = Counter(x for x in ls)# Counter calculates the propotion of class
    print('Target attribute class count(Yes/No)=',dict(cnt))
    total_instances = len(ls)  
    print("Total no of instances/records associated with {0} is: {1}".format(value,total_instances ))
    probs = [x / total_instances for x in cnt.values()]  # x means no of YES/NO
    print("Probability of Class {0} is: {1:.4f}".format(min(cnt),min(probs)))
    print("Probability of Class {0} is: {1:.4f}".format(max(cnt),max(probs)))
    return entropy(probs) # Call Entropy 


#Part 3-Computing Information Gain
def information_gain(df, split_attribute, target_attribute,battr):
    print("\n\n-----Information Gain Calculation of ",split_attribute, " --------") 
    df_split = df.groupby(split_attribute) # group the data based on attribute values
    glist=[]
    for gname,group in df_split:
        print('Grouped Attribute Values \n',group)
        glist.append(gname) 
    
    glist.reverse()
    nobs = len(df.index) * 1.0   
    df_agg1=df_split.agg({target_attribute:lambda x:entropy_of_list(x, glist.pop())})
    df_agg2=df_split.agg({target_attribute :lambda x:len(x)/nobs})
    
    df_agg1.columns=['Entropy']
    df_agg2.columns=['Proportion']
    
    # Calculate Information Gain:
    new_entropy = sum( df_agg1['Entropy'] * df_agg2['Proportion'])
    if battr !='S':
        old_entropy = entropy_of_list(df[target_attribute],'S-'+df.iloc[0][df.columns.get_loc(battr)])
    else:
        old_entropy = entropy_of_list(df[target_attribute],battr)
    return old_entropy - new_entropy

#Part 4-A fitting function for inducing the decision Tree
def id3(df, target_attribute, attribute_names, default_class=None,default_attr='S'):
    
    from collections import Counter
    cnt = Counter(x for x in df[target_attribute])# class of YES /NO
    
    
    if len(cnt) == 1:# First condition check: Is this split of the dataset homogeneous/similar
        return next(iter(cnt))  # next input data set, or raises StopIteration when EOF is hit.
    
    
    elif df.empty or (not attribute_names):# Second condition check: Is this split of the dataset empty? if yes, return a default value
        return default_class  # Return None for Empty Data Set
    
    
    else:## Otherwise Default condition: This dataset is ready for decision modeling
        # A.) We start by getting  Default Value for next recursive call of this function:
        default_class = max(cnt.keys()) #No of YES and NO Class
        
        gainz=[]# B.) Then Compute the Information Gain of the attributes:
        for attr in attribute_names:
            ig= information_gain(df, attr, target_attribute,default_attr)
            gainz.append(ig)
            print('Information gain of ',attr,' is : ',ig)
        
        index_of_max = gainz.index(max(gainz))               # Index of Best Attribute
        best_attr = attribute_names[index_of_max]            # Choose Best Attribute to split on
        print("\nAttribute with the maximum gain is: ", best_attr)
        
        # C.) The we create an empty tree, to be populated in a moment
        tree = {best_attr:{}} # Initiate the tree with best attribute as a node 
        remaining_attribute_names =[i for i in attribute_names if i != best_attr]
        
        # Split dataset-On each split, recursively/iteratively call this algorithm.Here, we populate the empty tree with subtrees, which are the result of the recursive call
        for attr_val, data_subset in df.groupby(best_attr):
            subtree = id3(data_subset,target_attribute, remaining_attribute_names,default_class,best_attr)
            tree[best_attr][attr_val] = subtree
        return tree #Return the build decision tree
    
    
#Part 5-Getting our results
from pprint import pprint
tree = id3(df,t,attribute_names)
print("\nThe Resultant Decision Tree is:")
pprint(tree) #See the reulting output, based on the attributes and levels

#Part 5-Testing our algorithm with testing dataset samples
def classify(instance, tree,default=None): # A function to test an instance of Play Tennis with Predicted model   
    attribute = next(iter(tree)) # Outlook/Humidity/Wind       
    if instance[attribute] in tree[attribute].keys(): # Value of the attributs in  set of Tree keys  
        result = tree[attribute][instance[attribute]]
        if isinstance(result, dict): # this is a tree, delve deeper
            return classify(instance, result)
        else:
            return result # this is a label
    else:
        return default
    
#Get the test dataset samples
df_new=pd.read_csv('PlayTennisTest.csv')
df_new['predicted'] = df_new.apply(classify, axis=1, args=(tree,'?')) 
print(df_new)

