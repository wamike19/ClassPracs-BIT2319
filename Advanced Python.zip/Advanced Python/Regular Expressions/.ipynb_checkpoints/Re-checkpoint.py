#Exercise 1-Using \w+ and \^  regular expressions
import re #Import a  regular expression library
xx="BIT 2319, learning is fun"
r1=re.findall(r"^\w+", xx) #^ implies match start of a string, and w+ implies alphanumeric character in the string
#r1=re.findall(r"^\w", xx) #^ implies match start of a string, and w+ one implies alphanumeric character in the string
print(r1)


#Exercise 2-Using re.split function and \s regular expressions 
import re
print((re.split(r'\s',"I want to bite your nose")))#split the words in the string
print((re.split(r's',"I want to bite your nose")))#split the words wherever it finds "s" character in the string

#See more patterns
import re
print((re.split(r'\d',"I want to bite your nose")))#
print((re.split(r'\D',"I want to bite your nose")))#
print((re.split(r'\$',"I want to bite your nose")))#
print((re.split(r'\b',"I want to bite your nose")))#

#Exercise 3- Using re.match method on a string
import re
list=["kariuki kapenda", "kuregarega kulala", "Kariuki loves", "lazinesss and sleep"]
for element in list:#Here k is our flag character
    z=re.match("(k\w+)\W(k\w+)",element) #"w+" and "\W" will match the words starting with letter 'k' 
    if z:
        print((z.groups()))#Note,anything which is not started with 'k' is not identified.
        
#Exercise 4- Using re.search( ) method on a string
import re
patterns=["artificiel intelligence", "word searching"]
text="We learnt how to do word searching in artificial Intelligence lab"

for pattern in patterns:
    print('I am looking for "%s" in "%s" ->'%(pattern,text), end ='')#Look for two string literal strings, in a text string.
    if re.search(pattern,text):
        print("Hurray, I found you words")#report a match
    else:
        print("mmh mmh,No matchingwords.")#report a no match
        
        
        
#Exercise 5- Using re.findall ( ) method on  strings  
import re
myEmailsFile= 'you@gmail.com, we@hotmail.com,use@dkut.ac.ke, them@jkuat.ac.ke,me@kimathi.dkut.ac.ke'

#emails=re.findall(r'[\w\.-]+@[\w\.-]+',myEmailsFile)
emails = re.findall(r'[\w\.-]+@[\w\.-]+', myEmailsFile)

for email in myEmailsFile:
    print(email)

# Exercise 6- Using re.M flags
import re
xx="""I love python.
But I dont know search with multi line. 
However I am learning this right now.
So I will improve with time """

k=re.findall(r"^\w",xx) #Print the first character in line 1
l=re.findall(r"^\w", xx,re.MULTILINE)#The flag multi-line helps to make the code to check every line in the string for the first charcter object.
print("In the first case, we check in only one line", k)
print("In the second case, we check in many lines",l)

