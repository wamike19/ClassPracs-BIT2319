#Exercise 34- Accesing online Data
import urllib.request

webUrl=urllib.request.urlopen('https?//website/mydata')

print("Result code:" +str(webUrl.getcode()))#get the resultant code and print it. e.g. 200 for success

#To read data from a html page
data=webUrl.read()#call the read function on the web url function, to read contents of data files.The content is put in a variable called data
print(data)#print the data into html format